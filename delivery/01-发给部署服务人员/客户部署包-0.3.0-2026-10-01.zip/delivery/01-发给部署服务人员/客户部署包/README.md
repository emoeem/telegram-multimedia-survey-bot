# 客户部署包

这是客户 Worker 的完整部署包。

## 你只需要做 3 件事

### 1. 安装

双击：

`00-安装依赖.cmd`

等待安装完成。

### 2. 登录客户 Cloudflare

在这个文件夹空白处按 Shift + 右键 → 打开 PowerShell：

```powershell
npx wrangler login
```

浏览器登录**客户自己的 Cloudflare 账号**。

### 3. 部署

双击：

`02-正式部署.cmd`

按提示填写：

1. 客户名称
2. 管理员 Telegram 数字 ID
3. Cloudflare Account ID（已经登录时通常直接回车）
4. 项目所有者提供的授权密钥
5. Telegram Bot Token
6. Cloudflare API Token（OAuth 登录时通常直接回车）

脚本会自动创建 D1、KV、Queue，执行全部数据库 migration，部署 Worker，设置 Telegram Webhook 和 Bot Commands。

## 预演

第一次不确定环境是否正确，可以先双击：

`01-预演部署.cmd`

预演不会创建远程资源，也不会部署 Worker。

## 部署完成后

访问：

```text
https://<worker>.workers.dev/health
```

然后：

```text
/start
```

管理员测试：

```text
/create
```

普通用户测试：

```text
/surveys
```

完成一次“创建 → 发布 → 填写 → 查看答卷 → 导出”测试。

最后把：

```text
customer-deployments/<worker-name>/deployment-manifest.json
Worker URL
验收结果
```

回传项目所有者。

## 安全

不要发送：

- Bot Token
- Cloudflare API Token
- LICENSE_KEY
- .customer-secrets.tmp
- 项目所有者的 LICENSE_ADMIN_TOKEN

客户每月续费由项目所有者处理。

续费后**不需要重新部署**，项目所有者只需要在授权中心发送：

```text
/license_extend <授权编号> 30
```

## 文件说明

| 文件 | 用途 |
|---|---|
| 00-安装依赖.cmd | 安装 Node.js 项目依赖 |
| 01-预演部署.cmd | 检查部署计划，不创建远程资源 |
| 02-正式部署.cmd | 一键正式部署 |
| scripts/deploy-customer.mjs | 实际部署程序，不要随意修改 |
| db/migrations/ | 客户 D1 数据库迁移 |
| src/ | Worker 源码 |

## 版本

见 VERSION.txt。
